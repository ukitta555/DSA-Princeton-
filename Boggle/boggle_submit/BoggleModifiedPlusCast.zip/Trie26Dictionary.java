import edu.princeton.cs.algs4.Queue;

import java.util.ArrayList;

public class Trie26Dictionary {
    private TrieNode root = null;
    private static final int R = 26;
    private Queue<String> wordsFromBoard;
    private Queue<TrieNode> nodesToReset;
    private ArrayList<Pair>[][] adjacentCubes;
    private char [][] boggleBoard;
    private boolean[][] visited;

    public Trie26Dictionary()
    {
        wordsFromBoard = new Queue<String>();
        nodesToReset = new Queue<TrieNode>();
    }
    private static class TrieNode
    {
        private int value = -1;
        private TrieNode[] next = new TrieNode [R];
    }

    private class Pair
    {
        private int i;
        private int j;
        public Pair(int i, int j)
        {
            this.i = i;
            this.j = j;
        }

        public String toString()
        {
            return "Pair{" +
                    "i=" + i +
                    ", j=" + j +
                    '}';
        }
    }

    public void add(String key)
    {
        root = add(root, key, 0);
    }

    private TrieNode add(TrieNode x, String key, int d)
    {
        if (x == null) x = new TrieNode();
        if (d == key.length())
        {
            x.value = 0;
            return x;
        }
        char c = key.charAt(d);
        x.next[c - 65] = add(x.next[c - 65], key, d+1);
        return x;
    }

    public boolean contains(String key, int delta)
    {
       // System.out.println (queryResult);
        return (get(key, delta) == 1);
    }

    public int get(String key, int delta)
    {
        TrieNode x = get(root, key, 0);
        if (x == null || x.value == -1) return -1;
        x.value += delta;
        if (x.value == 1)  nodesToReset.enqueue(x);
        return x.value;
    }

    private TrieNode get(TrieNode x, String key, int d)
    {
        if (x == null) return null;
        if (d == key.length()) return x;
        char c = key.charAt(d);
        return get(x.next[c - 65], key, d+1);
    }

    public Iterable<String> keys()
    {
        Queue<String> queue = new Queue<>();
        collect (root, queue, "");
        return queue;
    }

    private void collect(TrieNode x, Queue<String> queue, String prefix)
    {
        if (x == null) return ;
        if (x.value != -1) queue.enqueue(prefix);
        for (char c = 0; c < R; c++)
            collect(x.next[c], queue, prefix+(char)(c + 65));
    }


    private boolean checkNextNode(TrieNode x, char nextChar)
    {
        if (nextChar != 'Q')
        {
            if (x != null && x.next[nextChar - 65] != null) return true;
            return false;
        }
        else
        {
            TrieNode qNode = x.next[nextChar - 65];
            TrieNode uNode = null;
            if (qNode != null) uNode = qNode.next[20];
            if (qNode != null && uNode != null) return true;
            return false;
        }

    }

    // run modified DFS to find all words
    public void findAllWordsDFS(char[][] boggleBoard, int rows, int cols)
    {
        // form a matrix that will indicate whether we visited the node or not
        // remove the mark from the node when we visited all 8 possible neighbour nodes
        this.boggleBoard = boggleBoard;
        visited = new boolean[rows][cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                visited[i][j] = false;
            }
        }

        computeAdjacentCubes();
        TrieNode currentNode = root;

       // Stopwatch watch = new Stopwatch();
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                dfs(i, j, "", currentNode);
            }
        }
        //System.out.println("Elapsed time: " + watch.elapsedTime());
    }

    // modified recursive DFS itself
    private void dfs(int i, int j, String prefix, TrieNode currentNode)
    {
        // mark the visited node
        visited[i][j] = true;
        if (checkNextNode(currentNode, boggleBoard[i][j]))
        {

            if (boggleBoard[i][j] == 'Q')
            {
                prefix += "QU";
                currentNode = currentNode.next[boggleBoard[i][j] - 65];
                currentNode = currentNode.next[20];
            }
            else
            {
                currentNode = currentNode.next[boggleBoard[i][j] - 65];
                prefix +=  boggleBoard[i][j];
            }

            if (prefix.length() > 2 && contains(prefix, 1))
            {
                wordsFromBoard.enqueue(prefix);
            }

            for (Pair pair : adjacentCubes[i][j])
            {
                int nextI = pair.i;
                int nextJ = pair.j;
                if (!visited [nextI][nextJ])
                    dfs(nextI, nextJ, prefix, currentNode);
            }
        }
        // uncheck the node
        visited[i][j] = false;
    }

    public Iterable<String> getAllWords() { return wordsFromBoard; }

    public void resetSolverForNewBoard()
    {
        wordsFromBoard = new Queue<String>();
        for (TrieNode x : nodesToReset)
            x.value = 0;
        nodesToReset = new Queue<TrieNode>();
    }

    private void computeAdjacentCubes()
    {
        int rows = boggleBoard.length;
        int cols = boggleBoard[0].length;

        Pair indices;
        adjacentCubes = (ArrayList<Pair>[][]) new Object[rows][cols];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                adjacentCubes[i][j] = new  ArrayList<Pair>();
                if (i >= 1)
                {
                    if (j >= 1)
                    {
                        indices = new Pair(i - 1, j - 1);
                        adjacentCubes[i][j].add(indices);
                    }
                    indices = new Pair (i - 1, j);
                    adjacentCubes[i][j].add(indices);
                    if (j < cols-1)
                    {
                        indices = new Pair (i - 1, j + 1);
                        adjacentCubes[i][j].add(indices);
                    }
                }

                if (i < rows - 1)
                {
                    if (j >= 1)
                    {
                        indices = new Pair (i + 1, j - 1);
                        adjacentCubes[i][j].add(indices);
                    }
                    indices = new Pair (i + 1, j);
                    adjacentCubes[i][j].add(indices);
                    if (j < cols-1)
                    {
                        indices = new Pair(i + 1, j + 1);
                        adjacentCubes[i][j].add(indices);
                    }
                }

                if (j >= 1)
                {
                    indices = new Pair(i, j - 1);
                    adjacentCubes[i][j].add(indices);
                }
                if (j < cols-1)
                {
                    indices = new Pair(i, j + 1);
                    adjacentCubes[i][j].add(indices);
                }
            }
        }
    }

    public static void main(String[] args) {
        Trie26Dictionary trie = new Trie26Dictionary ();
        trie.add("HEAD");
        trie.add("AMBULA");
        trie.add("AMB");
        System.out.println(trie.contains("HEAD", 1));
        System.out.println(trie.contains("HEAD", 1));
        System.out.println(trie.contains("HEADER", 1));
        System.out.println(trie.contains("XD",1));
        for (String word : trie.keys())
            System.out.println(word);

        System.out.println ('X'-1);
        for (char c = 0; c < 10; c++)
        {
            System.out.println (c+1);
        }

    }
}
